
from fastapi import APIRouter
from services.rag import retrieve_docs
from services.llm import generate_answer, verify_answer

router = APIRouter()

@router.post("/ask")
async def ask(q: dict):
    question = q.get("question")

    docs = retrieve_docs(question)
    answer = generate_answer(question, docs)
    verification = verify_answer(question, answer, docs)

    return {
        "answer": answer,
        "verification": verification
    }
