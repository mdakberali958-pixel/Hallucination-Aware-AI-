
import google.generativeai as genai

genai.configure(api_key="YOUR_GEMINI_API_KEY")

model = genai.GenerativeModel("gemini-pro")

def generate_answer(q, docs):
    context = "\n".join(docs)
    prompt = f"Answer using only this context:\n{context}\nQuestion: {q}"

    return model.generate_content(prompt).text

def verify_answer(q, answer, docs):
    context = "\n".join(docs)
    prompt = f'''
    Check if the answer is fully supported by context.

    Context:
    {context}

    Question:
    {q}

    Answer:
    {answer}

    Output JSON:
    {{
        "supported": true/false,
        "reason": "..."
    }}
    '''

    return model.generate_content(prompt).text
