
from sentence_transformers import SentenceTransformer
import numpy as np

model = SentenceTransformer('all-MiniLM-L6-v2')

docs_db = [
    "Tesla was founded in 2003",
    "Python is a programming language"
]

embeddings = model.encode(docs_db)

def retrieve_docs(query, top_k=2):
    q_emb = model.encode([query])[0]
    scores = np.dot(embeddings, q_emb)

    top_idx = np.argsort(scores)[-top_k:][::-1]
    return [docs_db[i] for i in top_idx]
