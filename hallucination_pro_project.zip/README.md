
# Production-Level AI Hallucination Detector

## Features
- RAG-based retrieval
- LLM-based verification
- JSON hallucination detection
- Clean modular backend

## Run Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Open Frontend
Open index.html in browser
